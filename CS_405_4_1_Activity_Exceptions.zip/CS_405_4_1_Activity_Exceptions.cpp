// CS_405_4_1_Activity_Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <exception> // included for exception handling

// custom exception class derived form std::exception
class CustomException : public std::exception 
{
public:
    // override the what() method to provide custom exception message
    const char* what() const noexcept override
    {
        return "Custom exception occured in do_custom_application_logic";
    }

};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::runtime_error("Error in do_even_more_custom_application_logic");

    return true; // wont execute due to exception
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try 
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    catch (const std::exception& ex)
    {
        // handle the exception by displaying a message and the exception's what() message
        std::cout << "Exception caught in do_custom_application_logic: " << ex.what() << std::endl;
    }

    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl; // should not execute
}

float divide(float num, float den)
{
    if (den == 0)
    {
        // throwing an overflow_error exception for divide by zero
        throw std::overflow_error("Divide by zero exception in divide function");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::overflow_error& ex)
    {
        // handle the specific exception thrown by divide
        std::cout << "Exception caught in do_division: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ex)
    {
        // catch the custom exception explicitly
        std::cout << "CustomException caught in main: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        // catch other standard exceptions
        std::cout << "Standard exception caught in main: " << ex.what() << std::endl;
    }
    catch (...)
    {
        // catch any other exceptions not caught by previous handlers
        std::cout << "An unknown exception caught in main." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu