// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits> // included for streamsize

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // use getline() to safely read input and prevent overflow
  std::cin.getline(user_input, sizeof(user_input));

  if (std::cin.fail()) {
	  // if reading user input fails, the user entered too many characters

	  std::cin.clear(); // clear error state
	  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // discard remaining input

	  std::cout << "You entered too many characters. Only the first " << sizeof(user_input) - 1
		  << " were accepted." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
