#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// The global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // Initialize random seed
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// Create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
    // Create a smart pointer to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // Erase all elements in the collection, if any remain
        collection->clear();
        // Free the pointer
        collection.reset(nullptr);
    }

    // Helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Test that the collection smart pointer is not null upon creation
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // Is the collection created?
    ASSERT_TRUE(collection);

    // The underlying pointer should not be null
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // Is the collection empty?
    ASSERT_TRUE(collection->empty());

    // If empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 //TEST_F(CollectionTest, AlwaysFail)
 //{
 //  FAIL();
 //}

 // Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Is the collection empty?
    ASSERT_TRUE(collection->empty());
    // If empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // Is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // If not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Is the collection empty?
    ASSERT_TRUE(collection->empty());
    // If empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // The collection should not be empty
    ASSERT_FALSE(collection->empty());
    // The size should be 5
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max_size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    // For 0 entries
    ASSERT_EQ(collection->size(), 0);
    ASSERT_GE(collection->max_size(), collection->size());

    // For 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_GE(collection->max_size(), collection->size());

    // For 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_GE(collection->max_size(), collection->size());

    // For 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    // For 0 entries
    ASSERT_EQ(collection->size(), 0);
    ASSERT_GE(collection->capacity(), collection->size());

    // For 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_GE(collection->capacity(), collection->size());

    // For 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_GE(collection->capacity(), collection->size());

    // For 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    // Ensure the collection is empty
    ASSERT_EQ(collection->size(), 0);

    // Resize to 5
    collection->resize(5);

    // Check that the size is now 5
    ASSERT_EQ(collection->size(), 5);

    // Check that new elements are default initialized to 0
    for (size_t i = 0; i < collection->size(); ++i)
    {
        ASSERT_EQ((*collection)[i], 0);
    }
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    // Add 10 entries
    add_entries(10);
    ASSERT_EQ(collection->size(), 10);

    // Resize to 5
    collection->resize(5);

    // Check that the size is now 5
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZeroClearsCollection)
{
    // Add some entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    // Resize to 0
    collection->resize(0);

    // Check that the size is now 0
    ASSERT_EQ(collection->size(), 0);

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    // Clear the collection
    collection->clear();

    // Check that the size is now 0
    ASSERT_EQ(collection->size(), 0);

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    // Add entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    // Erase from begin to end
    collection->erase(collection->begin(), collection->end());

    // Check that the size is now 0
    ASSERT_EQ(collection->size(), 0);

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // Record initial capacity and size
    size_t initial_capacity = collection->capacity();
    size_t initial_size = collection->size();

    // Reserve more space
    collection->reserve(100);

    // Check that capacity has increased
    ASSERT_GE(collection->capacity(), 100);
    ASSERT_GT(collection->capacity(), initial_capacity);

    // Check that size remains the same
    ASSERT_EQ(collection->size(), initial_size);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
    // Add some entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    // Try to access an out-of-range index
    ASSERT_THROW(collection->at(5), std::out_of_range);
    ASSERT_THROW(collection->at(100), std::out_of_range);
}

// Test to verify that the collection can be sorted
TEST_F(CollectionTest, CanSortCollection)
{
    // Add entries
    add_entries(10);

    // Sort the collection
    std::sort(collection->begin(), collection->end());

    // Check that the collection is sorted
    for (size_t i = 1; i < collection->size(); ++i)
    {
        ASSERT_LE((*collection)[i - 1], (*collection)[i]);
    }
}

// Test to verify that reserving more than max_size throws a length_error exception
TEST_F(CollectionTest, ReserveMoreThanMaxSizeThrowsLengthError)
{
    // Try to reserve more than max_size()
    ASSERT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);
}
