// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for performance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // transform each character based on an xor of the key modded constrained to key length using a mod
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text;

    // implement loading the file into a string
    std::ifstream file(filename);
    if (!file)
    {
        std::cerr << "Could not open the file " << filename << std::endl;
        return "";
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    file_text = buffer.str();

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');

    // did we find a newline
    if (pos != std::string::npos)
    {
        // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Implement file saving
    // File format:
    // Line 1: student name
    // Line 2: timestamp (yyyy-mm-dd)
    // Line 3: key used
    // Line 4+: data

    // open the file in binary mode
    std::ofstream file(filename, std::ios::binary);
    if (!file)
    {
        std::cerr << "Could not open the file " << filename << " for writing." << std::endl;
        return;
    }

    // get current time
    std::time_t t = std::time(nullptr);
    std::tm tm;
#if defined(_MSC_VER) || defined(__MINGW32__)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif

    // format the date as yyyy-mm-dd
    char date_str[11];
    std::strftime(date_str, sizeof(date_str), "%Y-%m-%d", &tm);

    // write to the file
    file << student_name << "\n";
    file << date_str << "\n";
    file << key << "\n";
    // write the data as binary
    file.write(data.data(), data.size());

    file.close();
}


std::string read_encrypted_file(const std::string& filename, std::string& student_name, std::string& key)
{
    // open the file in binary mode
    std::ifstream file(filename, std::ios::binary);
    if (!file)
    {
        std::cerr << "Could not open the file " << filename << std::endl;
        return "";
    }
    std::string line;

    // read student name
    if (!std::getline(file, student_name))
    {
        std::cerr << "Could not read student name from file " << filename << std::endl;
        return "";
    }
    // read date (we can skip it)
    if (!std::getline(file, line))
    {
        std::cerr << "Could not read date from file " << filename << std::endl;
        return "";
    }
    // read key
    if (!std::getline(file, key))
    {
        std::cerr << "Could not read key from file " << filename << std::endl;
        return "";
    }

    // read the rest of the file as encrypted data
    // get current position
    std::streampos pos = file.tellg();
    // go to the end to get the size
    file.seekg(0, std::ios::end);
    std::streampos end = file.tellg();
    std::streamsize size = end - pos;

    // go back to the position after key
    file.seekg(pos);

    // read the encrypted data
    std::string encrypted_data(size, '\0');
    file.read(&encrypted_data[0], size);

    return encrypted_data;
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key = "password";

    // read the source string from the input file
    const std::string source_string = read_file(file_name);
    if (source_string.empty())
    {
        std::cerr << "Failed to read source file." << std::endl;
        return 1;
    }

    //std::cout << "Source string length: " << source_string.length() << std::endl;

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // extract the data after the first two lines
    std::istringstream iss(source_string);
    std::string line;
    std::getline(iss, line); // skip student name
    std::getline(iss, line); // skip website URL
    std::string data_string((std::istreambuf_iterator<char>(iss)),
        std::istreambuf_iterator<char>());

    //std::cout << "Extracted data length: " << data_string.length() << std::endl;

    // encrypt the data string with the key
    const std::string encrypted_data = encrypt_decrypt(data_string, key);
    //std::cout << "Encrypted data length: " << encrypted_data.length() << std::endl;

    // save the encrypted data to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_data);

    // read the encrypted file
    std::string decrypted_student_name, decrypted_key;
    std::string encrypted_content = read_encrypted_file(encrypted_file_name, decrypted_student_name, decrypted_key);
    if (encrypted_content.empty())
    {
        std::cerr << "Failed to read encrypted file." << std::endl;
        return 1;
    }

    // decrypt the encrypted content with the key
    const std::string decrypted_data = encrypt_decrypt(encrypted_content, key);
    //std::cout << "Decrypted data length: " << decrypted_data.length() << std::endl;

    // save the decrypted data to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_data);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}
