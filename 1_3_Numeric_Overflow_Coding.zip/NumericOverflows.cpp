// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Updated to consistently detect and prevent numeric overflow and underflow across all data types.

#include <iostream>     // For std::cout
#include <limits>       // For std::numeric_limits
#include <type_traits>  // For std::is_integral, std::is_floating_point
#include <cmath>        // For std::isfinite
#include <float.h>      // For _fpclass

/// <summary>
/// Template function to perform addition while detecting and preventing overflow.
/// Computes: start + (increment * steps)
/// </summary>
/// <typeparam name="T">A numeric type with basic math operations</typeparam>
/// <param name="start">The starting number</param>
/// <param name="increment">The value to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">The result of the addition if no overflow occurs</param>
/// <returns>True if addition succeeded without overflow, false if overflow occurred</returns>
/// 
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for overflow before performing the addition

        if (std::is_floating_point<T>::value)
        {
            // For floating-point types, check if the result is finite
            T temp_result = result + increment;

            // Explicitly cast to long double to resolve ambiguous call
            if (!std::isfinite(static_cast<long double>(temp_result)))
            {
                // Overflow occurred
                return false;
            }

            result = temp_result;
        }
        else if (std::is_unsigned<T>::value)
        {
            // For unsigned integer types, ensure result does not exceed max value
            if (result > std::numeric_limits<T>::max() - increment)
            {
                // Overflow would occur
                return false;
            }

            result += increment;
        }
        else if (std::is_signed<T>::value)
        {
            // For signed integer types, check for overflow
            if ((increment > 0) && (result > std::numeric_limits<T>::max() - increment))
            {
                // Overflow would occur
                return false;
            }
            else if ((increment < 0) && (result < std::numeric_limits<T>::min() - increment))
            {
                // Underflow would occur
                return false;
            }

            result += increment;
        }
        else
        {
            // Unknown type, cannot proceed
            return false;
        }
    }

    return true; // Addition succeeded without overflow
}

/// <summary>
/// Template function to perform subtraction while detecting and preventing underflow.
/// Computes: start - (decrement * steps)
/// </summary>
/// <typeparam name="T">A numeric type with basic math operations</typeparam>
/// <param name="start">The starting number</param>
/// <param name="decrement">The value to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">The result of the subtraction if no underflow occurs</param>
/// <returns>True if subtraction succeeded without underflow, false if underflow occurred</returns>
/// 
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for underflow before performing the subtraction

        if (std::is_floating_point<T>::value)
        {
            // For floating-point types, check if the result is finite and not subnormal
            T temp_result = result - decrement;

            // Explicitly cast to long double to resolve ambiguous call
            long double ld_temp_result = static_cast<long double>(temp_result);

            if (!std::isfinite(ld_temp_result))
            {
                // Underflow occurred
                return false;
            }

            // use _fpclass to check for subnormal numbers
            int classification = _fpclass(ld_temp_result);
            if (classification == _FPCLASS_NINF || classification == _FPCLASS_NN || classification == _FPCLASS_ND)
            {
                // Underflow occurred (Negative infinity, negative normal, negative denormal)
                return false;
            }

            result = temp_result;
        }
        else if (std::is_unsigned<T>::value)
        {
            // For unsigned integer types, ensure result does not go below zero
            if (result < decrement)
            {
                // Underflow would occur
                return false;
            }

            result -= decrement;
        }
        else if (std::is_signed<T>::value)
        {
            // For signed integer types, check for underflow
            if ((decrement > 0) && (result < std::numeric_limits<T>::min() + decrement))
            {
                // Underflow would occur
                return false;
            }
            else if ((decrement < 0) && (result > std::numeric_limits<T>::max() + decrement))
            {
                // Overflow would occur
                return false;
            }

            result -= decrement;
        }
        else
        {
            // Unknown type, cannot proceed
            return false;
        }
    }

    return true; // Subtraction succeeded without underflow
}

// NOTE:
//   The unary '+' operator is used to force the output to be interpreted as a number
//   in cases where std::cout might assume it is a character.

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    // How many times we will iterate
    const unsigned long int steps = 5;
    // How much we will add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // Our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";

    T result;
    bool success = add_numbers<T>(start, increment, steps, result);

    if (success)
    {
        std::cout << +result << " (No Overflow)" << std::endl;
    }
    else
    {
        std::cout << "Overflow detected" << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";

    success = add_numbers<T>(start, increment, steps + 1, result);

    if (success)
    {
        std::cout << +result << " (No Overflow)" << std::endl;
    }
    else
    {
        std::cout << "Overflow detected" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    const unsigned long long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // First operation: No underflow expected
    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    T result;
    bool success = subtract_numbers<T>(start, decrement, steps, result);

    if (success)
    {
        std::cout << +result << " (No Underflow)" << std::endl;
    }
    else
    {
        std::cout << "Underflow detected" << std::endl;
    }

    // Second operation: Adjust steps to intentionally cause underflow
    unsigned long long int steps_with_underflow = steps;

    if (std::is_floating_point<T>::value)
    {
        // For floating-point types, set steps to a large number to cause underflow
        steps_with_underflow = steps * 1000;
    }
    else if (std::is_unsigned<T>::value)
    {
        steps_with_underflow = (static_cast<unsigned long long int>(start) / static_cast<unsigned long long int>(decrement)) + 1;
    }
    else if (std::is_signed<T>::value)
    {
        // Use double for calculations to handle large values
        double start_d = static_cast<double>(start);
        double min_d = static_cast<double>(std::numeric_limits<T>::min());
        double decrement_d = static_cast<double>(decrement);
        steps_with_underflow = static_cast<unsigned long long int>(((start_d - min_d) / decrement_d) + 1);
    }

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << steps_with_underflow << ") = ";
    success = subtract_numbers<T>(start, decrement, steps_with_underflow, result);

    if (success)
    {
        std::cout << +result << " (No Underflow)" << std::endl;
    }
    else
    {
        std::cout << "Underflow detected" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing various C++ primitive types
    // Signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // Unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // Floating-point numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing various C++ primitive types
    // Signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // Unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // Floating-point numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    // Create a string of "*" to use in the console output
    const std::string star_line(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // Run the overflow tests
    do_overflow_tests(star_line);

    // Run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

